#include "DrawableObject.h"
DrawableObject::DrawableObject(float points[], int size, ShaderProgram *sp, int index, int size_index, int count) {
	Model temp(points, size);
	this->m = temp;
    this->VAO = m.setVBOVAO(index, size_index, count);
	this->sp = sp;
}

void DrawableObject::draw(GLFWwindow *window,string draw_something) {
    /*
    
    glm::mat4 view = glm::mat4(0.1f); // make sure to initialize matrix to identity matrix first
    float radius = 10.0f;
    float camX = static_cast<float>(sin(glfwGetTime()) * radius);
    float camZ = static_cast<float>(cos(glfwGetTime()) * radius);
    //view = glm::lookAt(glm::vec3(camX, 0.0f, camZ), glm::vec3(0.0f, 0.0f, 0.0f), glm::vec3(0.0f, 1.0f, 0.0f));


    glm::mat4 projection = glm::perspective(glm::radians(45.0f), (float)5000 / (float)3500, 0.1f, 100.0f);
    */
    

    /*
    glm::mat4 M = glm::mat4(1.0f);
    M = glm::rotate(glm::mat4(1.0f), GLfloat(0.5f), glm::vec3(0.0f, 1.0f, 0.0f));

    M = glm::rotate(M, GLfloat(0.5f), glm::vec3(1.0f, 0.0f, 0.0f));
    M = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, 0.0f, 1));
    M = glm::scale(glm::mat4(1.0f), glm::vec3(0.5f));
    */
    GLuint shaderProgram = this->sp->createShaderProgram();

    //Toto by melo byt v shaderProgramu
    glUseProgram(shaderProgram);

  

    GLint t_matrix_id = glGetUniformLocation(this->sp->shaderProgram, "modelMatrix");
    glUniformMatrix4fv(t_matrix_id, 1, GL_FALSE,&this->transformation->getMatrix()[0][0]);


    GLint v_matrix_id = glGetUniformLocation(this->sp->shaderProgram, "viewMatrix");
    glUniformMatrix4fv(v_matrix_id, 1, GL_FALSE, &this->sp->camera->getView()[0][0]);


    GLint p_matrix_id = glGetUniformLocation(this->sp->shaderProgram, "projectionMatrix");
    glUniformMatrix4fv(p_matrix_id, 1, GL_FALSE, &this->sp->camera->getProjection()[0][0]);

    

    //GLint idModelTransform = glGetUniformLocation(shaderProgram, "modelMatrix");

    //glUniformMatrix4fv(idModelTransform, 1, GL_FALSE, &M[0][0]);
    
    this->sp->checkStatus();


    glBindVertexArray(this->VAO);


    // draw triangles
    if (draw_something == "GL_TRIANGLES_QUADS") {
        glDrawArrays(GL_TRIANGLES, 0, 3*12); //mode,first,count //GL_TRIANGLES
    }
    else if (draw_something == "GL_QUADS") {
        glDrawArrays(GL_QUADS, 0, 4);
    }
    else {
        glDrawArrays(GL_TRIANGLES, 0, 3 * 12);
    }

}