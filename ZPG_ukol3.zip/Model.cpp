#include "Model.h"

Model::Model()
{
}

Model::Model(float tmp_points[], int size) {
    this->VBO = 0;
    this->VAO = 0;
   
    for (int i = 0; i < size; i++) {
        this->points[i] = tmp_points[i];
    }
}


GLuint Model::setVBOVAO(int index, int size, int count)
{

    glGenBuffers(1, &VBO); // generate the VBO
    glBindBuffer(GL_ARRAY_BUFFER, VBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(points), points, GL_STATIC_DRAW); //GL_STATIC_DRAW

    glGenVertexArrays(1, &VAO); //generate the VAO
    glBindVertexArray(VAO); //bind the VAO
    
    glBindBuffer(GL_ARRAY_BUFFER, VBO);

    
    glVertexAttribPointer(index, size, GL_FLOAT, GL_FALSE, count, NULL);
    glEnableVertexAttribArray(0); //enable vertex attributes

//    glVertexAttribPointer(1, 4, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(4 * sizeof(float)));
//    glEnableVertexAttribArray(1); //enable vertex attributes
    

    return VAO;
}
