#include "Camera.h"

Camera::Camera(float fov, float aspect, float near, float far)
{
	this->fov = fov;
	this->aspect = aspect;
	this->near = near;
	this->far = far;

	this->position = glm::vec3(0.0f, 0.5f, 3.0f);
	this->front = glm::vec3(0.0f, 0.0f, -1.0f);
	this->direction = glm::normalize(position - glm::vec3(0));
	this->up = glm::vec3(0.0f, 1.0f, 0.0f);
	this->camera_up = glm::cross(direction, glm::normalize(glm::cross(up, direction)));
}

glm::mat4 Camera::getView()
{
	this->view = glm::lookAt(position, position + front, camera_up);

	return this->view;
}

glm::mat4 Camera::getProjection()
{
	this->projection = glm::perspective(glm::radians(fov), aspect, near, far);
	return this->projection;
}


