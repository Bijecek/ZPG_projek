#include "Application.h"
#include "Camera.h"

Application::Application()
{
	createWindow(5000, 3500, "ZPG");
}
CameraMovement *Application::camera_movement = nullptr;

void mouseCallbackWrapper(GLFWwindow* window, double xpos, double ypos) {
    Application::camera_movement->handleMouse(window, xpos, ypos);
}
void Application::createWindow(int width, int height, const char* title)
{
    this->width = width;
    this->height = height;
    glfwSetErrorCallback(this->errorCallback);
    if (!glfwInit()) {
        fprintf(stderr, "ERROR: could not start GLFW3\n");
        exit(EXIT_FAILURE);
    }

    window = glfwCreateWindow(width, height, title, NULL, NULL);
    if (!window) {
        glfwTerminate();
        exit(EXIT_FAILURE);
    }

    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);

    // start GLEW extension handler
    glewExperimental = GL_TRUE;
    glewInit();

    glfwGetFramebufferSize(window, &width, &height);
    float ratio = width / (float)height;
    glViewport(0, 0, width, height);
}

void Application::printVersionInfo()
{
    // get version info
    printf("OpenGL Version: %s\n", glGetString(GL_VERSION));
    printf("Using GLEW %s\n", glewGetString(GLEW_VERSION));
    printf("Vendor %s\n", glGetString(GL_VENDOR));
    printf("Renderer %s\n", glGetString(GL_RENDERER));
    printf("GLSL %s\n", glGetString(GL_SHADING_LANGUAGE_VERSION));
    int major, minor, revision;
    glfwGetVersion(&major, &minor, &revision);
    printf("Using GLFW %i.%i.%i\n", major, minor, revision);
}




void Application::run()
{
    
    float points[] = {
     -0.5f, -0.5f,1,1,  1, 1, 0, 1,  // bottom left
      0.5f, -0.5f, 1,1,  1, 0, 0, 1,// bottom right
      0.5f, 0.5f, 1,1,   0, 0, 0, 1 ,// top right
     -0.5f, 0.5f,1,1,    0, 1, 0, 1,// top left
    };
    int size = sizeof(points) / sizeof(points[0]);
    
    float points1[] = {
      0.0f, 1.0f, 0.0f,
      -1.0f, -1.0f, 1.0f,
      1.0f, -1.0f, 1.0f,

      // Right
      0.0f, 1.0f, 0.0f,
      1.0f, -1.0f, 1.0f,
      1.0f, -1.0f, -1.0f,

      // Back
      0.0f, 1.0f, 0.0f,
      1.0f, -1.0f, -1.0f,
      -1.0f, -1.0f, -1.0f,

      // Left
      0.0f, 1.0f, 0.0f,
      -1.0f,-1.0f,-1.0f,
      -1.0f,-1.0f, 1.0f,
    };
    int size1 = sizeof(points1) / sizeof(points1[0]);
  
    float cube_data[] = {
    -1.0f,-1.0f,-1.0f, // triangle 1 : begin
    -1.0f,-1.0f, 1.0f,
    -1.0f, 1.0f, 1.0f, // triangle 1 : end
    1.0f, 1.0f,-1.0f, // triangle 2 : begin
    -1.0f,-1.0f,-1.0f,
    -1.0f, 1.0f,-1.0f, // triangle 2 : end
    1.0f,-1.0f, 1.0f,
    -1.0f,-1.0f,-1.0f,
    1.0f,-1.0f,-1.0f,
    1.0f, 1.0f,-1.0f,
    1.0f,-1.0f,-1.0f,
    -1.0f,-1.0f,-1.0f,
    -1.0f,-1.0f,-1.0f,
    -1.0f, 1.0f, 1.0f,
    -1.0f, 1.0f,-1.0f,
    1.0f,-1.0f, 1.0f,
    -1.0f,-1.0f, 1.0f,
    -1.0f,-1.0f,-1.0f,
    -1.0f, 1.0f, 1.0f,
    -1.0f,-1.0f, 1.0f,
    1.0f,-1.0f, 1.0f,
    1.0f, 1.0f, 1.0f,
    1.0f,-1.0f,-1.0f,
    1.0f, 1.0f,-1.0f,
    1.0f,-1.0f,-1.0f,
    1.0f, 1.0f, 1.0f,
    1.0f,-1.0f, 1.0f,
    1.0f, 1.0f, 1.0f,
    1.0f, 1.0f,-1.0f,
    -1.0f, 1.0f,-1.0f,
    1.0f, 1.0f, 1.0f,
    -1.0f, 1.0f,-1.0f,
    -1.0f, 1.0f, 1.0f,
    1.0f, 1.0f, 1.0f,
    -1.0f, 1.0f, 1.0f,
    1.0f,-1.0f, 1.0f
    };
    int size_cube = sizeof(cube_data) /  sizeof(cube_data[0]);

    
    Shader* v_shader = new Shader("#version 330\n"
        "layout(location=0) in vec4 vp;"
 //       "layout(location=1) in vec4 aColor;"
        "out vec4 ourColor;"
        "uniform mat4 modelMatrix;"
        "uniform mat4 viewMatrix;"
        "uniform mat4 projectionMatrix;"
        "void main () {"
        "     gl_Position = projectionMatrix * viewMatrix * modelMatrix * vec4 (vp);"
//        "     gl_Position = modelMatrix * vec4 (vp);"
 //       "     ourColor = aColor;"      
        "}");
 
    
    Shader* f_shader = new Shader("#version 330\n"
"out vec4 frag_colour;"
"in vec4 ourColor;"
"void main () {"
"     frag_colour = vec4 (1, 1, 0, 1);"
"}");

    Shader* v_shader1 = new Shader("#version 330\n"
        "layout(location=0) in vec4 vp;"
        "layout(location=1) in vec4 aColor;"
        "out vec4 ourColor;"
        "uniform mat4 modelMatrix;"
        "uniform mat4 viewMatrix;"
        "uniform mat4 projectionMatrix;"
        "void main () {"
        "     gl_Position = projectionMatrix * viewMatrix * modelMatrix * vec4 (vp);"
        "     ourColor = aColor;"
        "}");


    Shader* f_shader1 = new Shader("#version 330\n"
        "out vec4 frag_colour;"
        "in vec4 ourColor;"
        "void main () {"
        "     frag_colour = vec4 (1, 0, 0, 1);"
        "}");
    
    

        
    ShaderProgram* sm = new ShaderProgram();;
    sm->addShader(v_shader);
    sm->addShader(f_shader);

    ShaderProgram* sm1 = new ShaderProgram();;
    sm1->addShader(v_shader1);
    sm1->addShader(f_shader1);


    Camera* camera = new Camera(45.0f, this->width / this->height, 0.1f, 100.0f);
    Application::camera_movement = new CameraMovement(camera, this->width, this->height);
    sm->useCamera(camera);
    sm1->useCamera(camera);

    glfwSetCursorPosCallback(window, mouseCallbackWrapper);

    
    
   

    float angle=0;
    float w_key = 0;
    float s_key = 0;
    float a_key = 0;
    float d_key = 0;


    while (!glfwWindowShouldClose(window)) {
        Application::camera_movement->handleKeys(window);
        // clear color and depth buffer
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
        
        //Funguje
        //    DrawableObject* draw_Object = new DrawableObject(points, size, sm, 0, 4, 8*sizeof(float));
             DrawableObject* draw_Object = new DrawableObject(cube_data, size_cube, sm, 0, 3,0);
             draw_Object->transformation->scale->scaling(glm::vec3(0.1f));
            draw_Object->transformation->rotate->rotation(20.f, glm::vec3(0.2f,0,0.5f));
          

            draw_Object->draw(window,"GL_TRIANGLES_QUADS");

            DrawableObject* draw_Object1 = new DrawableObject(points1, size1, sm1, 0, 3, 0);
            draw_Object1->transformation->scale->scaling(glm::vec3(0.1f));
            draw_Object1->transformation->translate->translation(glm::vec3(1.0f, 2.0f, 0));

            draw_Object1->draw(window,"GL_TRIANGLES");



        // update other events like input handling
        glfwPollEvents();
        // put the stuff we�ve been drawing onto the display
        glfwSwapBuffers(window);
    }
    glfwDestroyWindow(window);

    glfwTerminate();
    exit(EXIT_SUCCESS);

}

void Application::errorCallback(int error, const char* description)
{
    fputs(description, stderr);
}

