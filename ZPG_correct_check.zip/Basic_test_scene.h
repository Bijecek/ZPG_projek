#pragma once
#include "Scene.h"
class Basic_test_scene : public Scene
{
public:
	Basic_test_scene();
	//void drawScene(GLFWwindow* window, int width, int height);
};

