#include "Application.h"

Application::Application()
{
	createWindow(1500, 900, "ZPG");
}

void Application::createWindow(int width, int height, const char* title)
{

    glfwSetErrorCallback(this->errorCallback);
    if (!glfwInit()) {
        fprintf(stderr, "ERROR: could not start GLFW3\n");
        exit(EXIT_FAILURE);
    }

    window = glfwCreateWindow(width, height, title, NULL, NULL);
    if (!window) {
        glfwTerminate();
        exit(EXIT_FAILURE);
    }

    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);

    // start GLEW extension handler
    glewExperimental = GL_TRUE;
    glewInit();

    glfwGetFramebufferSize(window, &width, &height);
    float ratio = width / (float)height;
    glViewport(0, 0, width, height);
}

void Application::printVersionInfo()
{
    // get version info
    printf("OpenGL Version: %s\n", glGetString(GL_VERSION));
    printf("Using GLEW %s\n", glewGetString(GLEW_VERSION));
    printf("Vendor %s\n", glGetString(GL_VENDOR));
    printf("Renderer %s\n", glGetString(GL_RENDERER));
    printf("GLSL %s\n", glGetString(GL_SHADING_LANGUAGE_VERSION));
    int major, minor, revision;
    glfwGetVersion(&major, &minor, &revision);
    printf("Using GLFW %i.%i.%i\n", major, minor, revision);
}

void Application::run()
{
  
    
    float points[] = {
     -1, -0.5f, 0.0f,1,  1, 1, 0, 1,  // bottom left
      0, -0.5f, 0.0f,1,  1, 0, 0, 1,// bottom right
      0, 0.5f, 0.0f,1,   0, 0, 0, 1 ,// top right
     -1, 0.5f,0.0f,1,    0, 1, 0, 1,// top left
    };
    int size = sizeof(points) / sizeof(points[0]);
    
    float points1[] = {
       0, -0.5f, 0.0f,1,  1, 1, 0, 1,  // bottom left
      1, -0.5f, 0.0f,1,  1, 0, 0, 1,// bottom right
      0, 0.5f,0.0f,1,   0, 0, 0, 1 ,// top right
     1, 0.5f, 0.0f,1,    0, 1, 0, 1,// top left
    };
    int size1 = sizeof(points1) / sizeof(points1[0]);
  
/*
    Model sp(points,size);
    GLuint VAO = sp.setVBOVAO();

    Model sp1(points1, size1);
    GLuint VAO1 = sp1.setVBOVAO();
*/
    
    Shader* v_shader = new Shader("#version 330\n"
        "layout(location=0) in vec4 vp;"
        "layout(location=1) in vec4 aColor;"
        "out vec4 ourColor;"
        "uniform mat4 modelMatrix;"
        "void main () {"
        "     gl_Position = vec4 (vp)* modelMatrix;"
        "     ourColor = aColor;"      
        "}");
 
    
    Shader* f_shader = new Shader("#version 330\n"
"out vec4 frag_colour;"
"in vec4 ourColor;"
"void main () {"
"     frag_colour = vec4 (ourColor);"
"}");
    
    

        
    ShaderProgram* sm = new ShaderProgram();;
    sm->addShader(v_shader);
    sm->addShader(f_shader);

    ShaderProgram* sm1 = new ShaderProgram();;
    sm1->addShader(v_shader);
    sm1->addShader(f_shader);



    
    
   


    while (!glfwWindowShouldClose(window)) {
        // clear color and depth buffer
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
        
        DrawableObject* draw_Object = new DrawableObject(points, size, sm);
        draw_Object->transformation->scale->scaling(glm::vec3(0.5));
        draw_Object->draw();

        DrawableObject* draw_Object1 = new DrawableObject(points1, size1, sm1);
        draw_Object1->transformation->scale->scaling(glm::vec3(0.5));
        draw_Object1->draw();
        /*
        
        GLuint shaderProgram1 = sm1.createShaderProgram();

        glUseProgram(shaderProgram1);

        sm1.checkStatus();

        glBindVertexArray(VAO1);

        glDrawArrays(GL_TRIANGLES, 0, 3);
        */
        // update other events like input handling
        glfwPollEvents();
        // put the stuff we�ve been drawing onto the display
        glfwSwapBuffers(window);
    }
    glfwDestroyWindow(window);

    glfwTerminate();
    exit(EXIT_SUCCESS);

}

void Application::errorCallback(int error, const char* description)
{
    fputs(description, stderr);
}
