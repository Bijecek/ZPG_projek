#include "DrawableObject.h"
DrawableObject::DrawableObject(float points[], int size, ShaderProgram *sp) {
	Model temp(points, size);
	this->m = temp;
    this->VAO = m.setVBOVAO();
	this->sp = sp;
}

void DrawableObject::draw() {
    /*
    glm::mat4 M = glm::mat4(1.0f);
    M = glm::rotate(glm::mat4(1.0f), GLfloat(0.5f), glm::vec3(0.0f, 1.0f, 0.0f));

    M = glm::rotate(M, GLfloat(0.5f), glm::vec3(1.0f, 0.0f, 0.0f));
    M = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, 0.0f, 1));
    M = glm::scale(glm::mat4(1.0f), glm::vec3(0.5f));
    */
    GLuint shaderProgram = this->sp->createShaderProgram();

    //Toto by melo byt v shaderProgramu
    glUseProgram(shaderProgram);

    GLint t_matrix_id = glGetUniformLocation(this->sp->shaderProgram, "modelMatrix");
    glUniformMatrix4fv(t_matrix_id, 1, GL_FALSE,&this->transformation->getMatrix()[0][0]);

    //GLint idModelTransform = glGetUniformLocation(shaderProgram, "modelMatrix");

    //glUniformMatrix4fv(idModelTransform, 1, GL_FALSE, &M[0][0]);
    
    this->sp->checkStatus();


    glBindVertexArray(this->VAO);

    // draw triangles
    glDrawArrays(GL_TRIANGLES, 0, 3); //mode,first,count //GL_TRIANGLES
}