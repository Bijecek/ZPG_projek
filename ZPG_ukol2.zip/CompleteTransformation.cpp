#include "CompleteTransformation.h"

glm::mat4 CompleteTransformation::getMatrix()
{
    glm::mat4 matrix = rotate->getMatrix() * translate->getMatrix() * scale->getMatrix();
    return matrix;
}
