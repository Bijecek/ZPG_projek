#include "ShaderProgram.h"

ShaderProgram::ShaderProgram() {};

void ShaderProgram::addShader(Shader *sh) {
	shader_Array.push_back(*sh);
}

void ShaderProgram::attachShaders() {
	for (int i = 0; i < shader_Array.size(); i++) {
		if (shader_Array[i].isVertex()) {
			glAttachShader(shaderProgram, shader_Array[i].createVertex());
		}
		else {
			glAttachShader(shaderProgram, shader_Array[i].createFragment());

		}
	}
	glLinkProgram(shaderProgram);

}
void ShaderProgram::checkStatus() {
	GLint status;
	glGetProgramiv(shaderProgram, GL_LINK_STATUS, &status);
	if (status == GL_FALSE)
	{
		GLint infoLogLength;
		glGetProgramiv(shaderProgram, GL_INFO_LOG_LENGTH, &infoLogLength);
		GLchar* strInfoLog = new GLchar[infoLogLength + 1];
		glGetProgramInfoLog(shaderProgram, infoLogLength, NULL, strInfoLog);
		fprintf(stderr, "Linker failure: %s\n", strInfoLog);
		delete[] strInfoLog;
	}
}
GLuint ShaderProgram::createShaderProgram()
{
	shaderProgram = glCreateProgram();

	attachShaders();

	return shaderProgram;


}
