#pragma once
#include "Shader.h"
#include <GL/glew.h>
//Include GLFW
#include <glfw3.h> 
//Include the standard C++ headers  
#include <stdlib.h>
#include <stdio.h>
#include <vector>
using namespace std;

class ShaderManager
{
	vector<Shader> shader_Array;
	GLuint shaderProgram;
public:
	ShaderManager();
	void addShader(Shader *sh);
	GLuint createShaderProgram();
	void checkStatus();
	void attachShaders();
	
};

