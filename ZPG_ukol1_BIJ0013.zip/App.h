#pragma once
#include "Shader.h"
#include <GL/glew.h>
//Include GLFW
#include <glfw3.h> 
//Include the standard C++ headers  
#include "ShaderProgram.h"
#include "ShaderManager.h"
#include <stdlib.h>
#include <stdio.h>
#include <vector>
#include <malloc.h>
using namespace std;

class App
{
	GLFWwindow* window;

public:
	App();
	void createWindow(int width, int height, const char* title);
	void printVersionInfo();
	void run();
	static void errorCallback(int error, const char* description);

};

