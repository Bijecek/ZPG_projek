
#include "App.h"





int main()
{
	App app = App();
	app.printVersionInfo();
	app.run();

}
