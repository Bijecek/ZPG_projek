#include "App.h"

App::App()
{
	createWindow(800, 600, "ZPG");
}

void App::createWindow(int width, int height, const char* title)
{
    glfwSetErrorCallback(this->errorCallback);
    if (!glfwInit()) {
        fprintf(stderr, "ERROR: could not start GLFW3\n");
        exit(EXIT_FAILURE);
    }

    window = glfwCreateWindow(width, height, title, NULL, NULL);
    if (!window) {
        glfwTerminate();
        exit(EXIT_FAILURE);
    }

    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);

    // start GLEW extension handler
    glewExperimental = GL_TRUE;
    glewInit();

    glfwGetFramebufferSize(window, &width, &height);
    float ratio = width / (float)height;
    glViewport(0, 0, width, height);
}

void App::printVersionInfo()
{
    // get version info
    printf("OpenGL Version: %s\n", glGetString(GL_VERSION));
    printf("Using GLEW %s\n", glewGetString(GLEW_VERSION));
    printf("Vendor %s\n", glGetString(GL_VENDOR));
    printf("Renderer %s\n", glGetString(GL_RENDERER));
    printf("GLSL %s\n", glGetString(GL_SHADING_LANGUAGE_VERSION));
    int major, minor, revision;
    glfwGetVersion(&major, &minor, &revision);
    printf("Using GLFW %i.%i.%i\n", major, minor, revision);
}

void App::run()
{
  
    
    float points[] = {
     -0.5f, -0.5f, 0.0f,1,  1, 1, 0, 1,  // bottom left
      0.5f, -0.5f, 0.0f,1,  1, 0, 0, 1,// bottom right
      0.5f, 0.5f, 0.0f,1,   0, 0, 0, 1 ,// top right
     -0.5f, 0.5f,0.0f,1,    0, 1, 0, 1,// top left
    };
    int size = sizeof(points) / sizeof(points[0]);
    
    
  
    
    ShaderProgram sp(points,size);
    GLuint VAO = sp.setVBOVAO();

    
    Shader* v_shader = new Shader("#version 330\n"
        "layout(location=0) in vec4 vp;"
        "layout(location=1) in vec4 aColor;"
        "out vec4 ourColor;"
        "void main () {"
        "     gl_Position = vec4 (vp);"
        "     ourColor = aColor;"      
        "}");
 
    
    Shader* f_shader = new Shader("#version 330\n"
"out vec4 frag_colour;"
"in vec4 ourColor;"
"void main () {"
"     frag_colour = vec4 (ourColor);"
"}");
    
   

        
    ShaderManager sm;
    sm.addShader(v_shader);
    sm.addShader(f_shader);
    


    while (!glfwWindowShouldClose(window)) {
        // clear color and depth buffer
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
        GLuint shaderProgram = sm.createShaderProgram();
        glUseProgram(shaderProgram);
        sm.checkStatus();

        glBindVertexArray(VAO);
        // draw triangles
        glDrawArrays(GL_QUADS, 0, 4); //mode,first,count //GL_TRIANGLES
        // update other events like input handling
        glfwPollEvents();
        // put the stuff we�ve been drawing onto the display
        glfwSwapBuffers(window);
    }
    glfwDestroyWindow(window);

    glfwTerminate();
    exit(EXIT_SUCCESS);

}

void App::errorCallback(int error, const char* description)
{
    fputs(description, stderr);
}
