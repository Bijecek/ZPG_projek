float base_rectangle[] = {
     -0.5f, -0.5f, 0.0f,1,  1, 1, 0, 1,  // bottom left
      0.5f, -0.5f, 0.0f,1,  1, 0, 0, 1,// bottom right
      0.5f, 0.5f, 0.0f,1,   0, 0, 0, 1 ,// top right
     -0.5f, 0.5f,0.0f,1,    0, 1, 0, 1,// top left
};