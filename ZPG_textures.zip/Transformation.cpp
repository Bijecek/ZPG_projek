#include "Transformation.h"

glm::mat4 Transformation::getMatrix()
{
    return this->M;
}
Transformation::Transformation(){}