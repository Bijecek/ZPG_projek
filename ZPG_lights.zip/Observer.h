#pragma once
//Class subject
class Observer
{
public:
	virtual void notify() = 0;
};

// include Observer
// Subject classa:
//Attach Observer
//Notify
//vector observers