#pragma once
#include <GL/glew.h>
//Include GLFW
#include <glfw3.h> 
//Include the standard C++ headers  
#include <stdlib.h>
#include <stdio.h>
#include <vector>
#include <malloc.h>
#include <cstdio>
#include <iostream>
using namespace std;

class Model
{
	GLuint VBO;
	GLuint VAO;
	float points[500];
public:
	Model();
	Model(float tmp_points[], int size);
	GLuint setVBOVAO(int index, int size, int count);
};

