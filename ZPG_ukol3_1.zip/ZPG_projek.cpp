
#include "Application.h"





int main()
{
	Application app = Application();
	app.printVersionInfo();
	app.run();

}
