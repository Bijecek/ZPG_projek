#pragma once
#include "Scene.h"


class four_spheres_scene : public Scene
{
};

